"""Build the golden evaluation set.

Real workflow: run this to SAMPLE, then `scripts/label_golden.py` to hand-label.
For the bundled sample corpus, `--auto` fills labels by applying the annotation
guide's rubric programmatically, so a reviewer gets a runnable harness. Those
labels are marked `labeller: "rubric-sim"` and every report number derived from
them carries that caveat.
"""
from __future__ import annotations
import argparse, csv, json, random, re, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src import config, taxonomy
from src.data.load import load_brand_threads, split_threads

RARE_SEEDS = {
    "family_or_duo_plan": ("family", "duo", "plan manager", "member", "invite"),
    "feature_request_or_feedback": ("please add", "bring back", "redesign", "love the", "feature"),
    "device_integration": ("alexa", "car", "sonos", "bluetooth", "playstation", "tv"),
    "content_missing": ("greyed", "not available", "removed", "album", "artwork"),
}


def is_hard(text: str) -> bool:
    return (len(text) < 25 or len(text) > 220 or text.isupper()
            or len(re.findall(r"[^\w\s,.!?'<>/-]", text)) > 3)


# --- rubric simulation (ONLY used with --auto) ------------------------------ #
HUMAN_ESCALATE_CUES = re.compile(
    r"\b(refund|charged|billed|payment|hacked|compromised|locked out|password|"
    r"cancel|lawyer|legal|fraud|gdpr|third time|still not|been \d+ days|"
    r"ridiculous|unacceptable|joke|leaving|double billed)\b", re.I)


def rubric_escalate(text: str, intent: str) -> bool:
    """Applies data/golden/ANNOTATION_GUIDE.md, NOT src/agent/route.py."""
    if intent in ("billing_and_subscription", "account_access"):
        return True
    if HUMAN_ESCALATE_CUES.search(text):
        return True
    if len(text.strip()) < 12:            # "you genuinely do not understand"
        return True
    return False


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", default="sample", choices=["sample", "real"])
    ap.add_argument("--n", type=int, default=200)
    ap.add_argument("--auto", action="store_true", help="apply rubric programmatically")
    ap.add_argument("--out", default=str(config.GOLDEN / "golden_set.jsonl"))
    args = ap.parse_args()

    threads = load_brand_threads(args.source)
    _, holdout = split_threads(threads)
    rng = random.Random(config.SPLIT_SEED)

    gold_map = {}
    side = config.SAMPLE / "sample_gold_intents.csv"
    if args.auto and args.source == "sample" and side.exists():
        with side.open() as fh:
            gold_map = {r["tweet_id"]: r["intent"] for r in csv.DictReader(fh)}

    n_uniform, n_rare, n_hard = int(args.n * .55), int(args.n * .25), int(args.n * .20)
    pool = {t.thread_id: t for t in holdout}
    chosen: dict[str, str] = {}

    for t in rng.sample(holdout, min(n_uniform, len(holdout))):
        chosen[t.thread_id] = "uniform"

    rare_pool = [t for t in holdout if t.thread_id not in chosen
                 and any(s in t.opening_text.lower()
                         for seeds in RARE_SEEDS.values() for s in seeds)]
    for t in rng.sample(rare_pool, min(n_rare, len(rare_pool))):
        chosen[t.thread_id] = "rare_boost"

    hard_pool = [t for t in holdout if t.thread_id not in chosen and is_hard(t.opening_text)]
    for t in rng.sample(hard_pool, min(n_hard, len(hard_pool))):
        chosen[t.thread_id] = "hard_case"

    rest = [t for t in holdout if t.thread_id not in chosen]
    while len(chosen) < args.n and rest:
        chosen[rest.pop().thread_id] = "uniform"

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    n_written = 0
    with out.open("w", encoding="utf-8") as fh:
        for tid, stratum in chosen.items():
            t = pool[tid]
            gi = gold_map.get(tid)
            rec = {
                "id": tid, "stratum": stratum, "text": t.opening_text,
                "raw_text": t.opening_raw,
                "gold_intent": gi if args.auto else None,
                "gold_escalate": rubric_escalate(t.opening_text, gi) if (args.auto and gi) else None,
                "ambiguous": False,
                "had_brand_reply": bool(t.first_brand_reply),
                "reference_reply": t.first_brand_reply,
                "labeller": "rubric-sim" if args.auto else None,
            }
            fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
            n_written += 1

    print(f"wrote {n_written} examples -> {out}")
    if not args.auto:
        print("Now run: python scripts/label_golden.py")


if __name__ == "__main__":
    main()
