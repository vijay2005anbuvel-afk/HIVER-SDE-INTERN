"""Run the agent on one message. `python scripts/demo.py "my app keeps crashing"`"""
from __future__ import annotations
import json, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src import config
from src.data.load import load_brand_threads, split_threads, normalise
from src.agent.retrieve import ResolutionIndex
from src.agent.pipeline import SupportAgent
from src.llm import get_provider
from src.eval.grounding_check import check

msg = " ".join(sys.argv[1:]) or "my app keeps crashing on android since the update"
provider_name = "anthropic" if "--anthropic" in sys.argv else config.DEFAULT_PROVIDER
msg = msg.replace("--anthropic", "").strip()

kb, _ = split_threads(load_brand_threads("sample"))
index = ResolutionIndex(kb)
agent = SupportAgent(index, get_provider(provider_name))
o = agent.handle(normalise(msg))
g = check(o.reply, " ".join(p.brand_reply for p in index.search(normalise(msg))))

print(json.dumps({
    "message": msg, "intent": o.intent, "confidence": o.confidence,
    "action": o.action, "reason": o.escalation_reason, "rule": o.rule,
    "priority": o.priority, "reply": o.reply,
    "retrieval_support": o.retrieval_support,
    "grounding_violations": g.violations, "latency_ms": o.latency_ms,
}, indent=2))
