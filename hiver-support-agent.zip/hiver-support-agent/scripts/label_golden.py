"""Terminal labelling tool. Resumable: re-running skips already-labelled rows."""
from __future__ import annotations
import json, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src import config, taxonomy

PATH = config.GOLDEN / "golden_set.jsonl"


def main() -> None:
    rows = [json.loads(l) for l in PATH.read_text(encoding="utf-8").splitlines() if l.strip()]
    menu = {str(i + 1): n for i, n in enumerate(taxonomy.INTENT_NAMES)}
    todo = [r for r in rows if not r.get("gold_intent")]
    print(f"{len(todo)} unlabelled of {len(rows)}. Ctrl-C saves and exits.\n")
    print("\n".join(f"  {k}. {v}" for k, v in menu.items()))

    try:
        for n, r in enumerate(todo, 1):
            print(f"\n[{n}/{len(todo)}] ({r['stratum']})\n  {r['raw_text']}")
            while True:
                c = input("  intent # (a=ambiguous suffix, e.g. '3a') > ").strip()
                key = c.rstrip("a")
                if key in menu:
                    r["gold_intent"], r["ambiguous"] = menu[key], c.endswith("a")
                    break
                print("  ?")
            r["gold_escalate"] = input("  escalate? [y/N] > ").strip().lower().startswith("y")
            r["labeller"] = "human"
    except (KeyboardInterrupt, EOFError):
        print("\ninterrupted - saving")

    PATH.write_text("\n".join(json.dumps(r, ensure_ascii=False) for r in rows) + "\n",
                    encoding="utf-8")
    done = sum(1 for r in rows if r.get("gold_intent"))
    print(f"saved. {done}/{len(rows)} labelled.")


if __name__ == "__main__":
    main()
