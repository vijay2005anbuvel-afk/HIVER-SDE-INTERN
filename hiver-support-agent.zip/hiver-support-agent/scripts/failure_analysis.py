"""Mine artifacts/*_predictions.jsonl for failure modes, with real examples.

Produces artifacts/failures.json + a readable digest. Everything in REPORT.md's
failure section is generated from here, not hand-picked.
"""
from __future__ import annotations
import json, sys
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src import config
from src.eval.grounding_check import check


def main() -> None:
    preds = [json.loads(l) for l in
             (config.ARTIFACTS / "agent_predictions.jsonl").read_text().splitlines() if l.strip()]

    out: dict[str, dict] = {}

    # 1. unsafe automation - gold said escalate, we auto-sent
    unsafe = [p for p in preds if p["gold_escalate"] and p["pred_action"] == "auto"]
    out["unsafe_automation"] = {
        "count": len(unsafe), "rate": round(len(unsafe) / len(preds), 4),
        "examples": [{"msg": p["message"], "pred_intent": p["pred_intent"],
                      "gold_intent": p["gold_intent"], "reply": p["reply"][:160]}
                     for p in unsafe[:5]],
    }

    # 2. intent confusions, ranked
    conf = Counter((p["gold_intent"], p["pred_intent"]) for p in preds
                   if p["gold_intent"] != p["pred_intent"])
    out["intent_confusions"] = {
        "count": sum(conf.values()),
        "top_pairs": [{"gold": g, "pred": pr, "n": n,
                       "examples": [x["message"] for x in preds
                                    if x["gold_intent"] == g and x["pred_intent"] == pr][:3]}
                      for (g, pr), n in conf.most_common(6)],
    }

    # 3. confidently wrong - the dangerous quadrant
    cw = [p for p in preds if p["gold_intent"] != p["pred_intent"] and p["confidence"] >= 0.75]
    out["confidently_wrong"] = {
        "count": len(cw),
        "share_of_errors": round(len(cw) / max(1, conf.total()), 4),
        "examples": [{"msg": p["message"], "gold": p["gold_intent"],
                      "pred": p["pred_intent"], "conf": p["confidence"]} for p in cw[:5]],
    }

    # 4. ungrounded auto replies
    ung = []
    for p in preds:
        if p["pred_action"] != "auto" or "precedents_text" not in p:
            continue
        r = check(p["reply"], p["precedents_text"])
        if not r.supported:
            ung.append({"msg": p["message"], "reply": p["reply"][:140],
                        "violations": r.violations, "severity": r.severity})
    out["ungrounded_auto_replies"] = {
        "count": len(ung),
        "kinds": dict(Counter(v.split(":")[0] for u in ung for v in u["violations"])),
        "examples": ung[:5],
    }

    # 5. retrieval misses - low precedent support
    weak = sorted([p for p in preds], key=lambda p: p["retrieval_support"])[:12]
    out["weak_retrieval"] = {
        "count": sum(1 for p in preds if p["retrieval_support"] < config.MIN_RETRIEVAL_SIM),
        "examples": [{"msg": p["message"], "sim": p["retrieval_support"],
                      "action": p["pred_action"]} for p in weak[:5]],
    }

    # 6. which rule drives escalation - is one rule doing all the work?
    out["escalation_rule_mix"] = dict(
        Counter(p["rule"] for p in preds if p["pred_action"] == "escalate").most_common())

    # 7. per-stratum error concentration
    by = defaultdict(lambda: [0, 0])
    for p in preds:
        by[p["stratum"]][1] += 1
        if p["gold_intent"] != p["pred_intent"]:
            by[p["stratum"]][0] += 1
    out["errors_by_stratum"] = {k: {"errors": v[0], "n": v[1],
                                    "err_rate": round(v[0] / v[1], 4)} for k, v in by.items()}

    (config.ARTIFACTS / "failures.json").write_text(json.dumps(out, indent=2, ensure_ascii=False))
    print(json.dumps({k: (v if not isinstance(v, dict) else
                          {kk: vv for kk, vv in v.items() if kk != "examples"})
                      for k, v in out.items()}, indent=2)[:2600])


if __name__ == "__main__":
    main()
