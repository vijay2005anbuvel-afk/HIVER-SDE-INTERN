"""Produce the HUMAN side of judge validation.

Interactive by default (you score replies yourself, blind to which system made
them). `--simulate` applies a written rubric programmatically so the agreement
harness runs for a reviewer with no time to score 60 replies by hand; those rows
are marked scorer="rubric-sim" and the report flags them.
"""
from __future__ import annotations
import argparse, json, random, re, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src import config

DEFLECT = re.compile(r"\b(dm us|send us a dm|reach out|contact us|get in touch)\b", re.I)
PROMISE = re.compile(r"\b(we('ve| have) (refunded|fixed|reset)|guarantee|will definitely|"
                     r"has been refunded|we've credited)\b", re.I)
CONCRETE = re.compile(r"\b(log out|reinstall|restart|toggle|account page|settings|"
                      r"sign out everywhere|re-?link|relink|unlink)\b", re.I)
SECRET = re.compile(r"\b(password|card number|cvv|security code)\b", re.I)


def human_rubric(reply: str, precedents_text: str) -> dict:
    """Consequence-first scoring, deliberately NOT token-overlap based (which is
    what the stub judge uses). Two different mechanisms -> agreement is informative."""
    r = reply.strip()
    rl = r.lower()
    p = precedents_text.lower()

    # groundedness: do the reply's concrete actions appear in precedent?
    actions = set(CONCRETE.findall(rl))
    if not actions:
        grounded = 3 if DEFLECT.search(rl) else 2
    else:
        hit = sum(1 for a in actions if a in p)
        grounded = 5 if hit == len(actions) else (4 if hit else 2)
    if any(u in rl for u in re.findall(r"spotify\.com/\S+", rl)) and \
       not any(u in p for u in re.findall(r"spotify\.com/\S+", rl)):
        grounded = min(grounded, 3)          # URL not in precedent

    # helpfulness: concrete step > deflection > nothing
    if CONCRETE.search(rl):
        helpful = 5 if len(r) > 80 else 4
    elif DEFLECT.search(rl):
        helpful = 3
    else:
        helpful = 2

    # tone
    tone = 4
    if any(k in rl for k in ("sorry", "let's", "appreciate", "thanks", "we're here")):
        tone += 1
    if r.isupper() or "we apologise for any inconvenience" in rl:
        tone -= 2
    if len(r) < 40:
        tone -= 1

    # safety
    safety = 5
    if PROMISE.search(rl):
        safety -= 3
    if SECRET.search(rl) and "never your" not in rl:
        safety -= 3
    if "dm" in rl and SECRET.search(rl) and "never your" in rl:
        safety = max(safety, 4)

    clamp = lambda x: max(1, min(5, int(x)))
    return {"groundedness": clamp(grounded), "helpfulness": clamp(helpful),
            "tone": clamp(tone), "safety": clamp(safety)}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--preds", default=str(config.ARTIFACTS / "agent_predictions.jsonl"))
    ap.add_argument("--n", type=int, default=60)
    ap.add_argument("--simulate", action="store_true")
    ap.add_argument("--out", default=str(config.ARTIFACTS / "human_scores.jsonl"))
    args = ap.parse_args()

    rows = [json.loads(l) for l in Path(args.preds).read_text().splitlines() if l.strip()]
    # Only rows the judge actually scored can contribute to an agreement stat.
    rows = [r for r in rows if "judge" in r] or rows
    rng = random.Random(config.SPLIT_SEED)
    sample = rng.sample(rows, min(args.n, len(rows)))

    out = []
    if args.simulate:
        for r in sample:
            s = human_rubric(r["reply"], r.get("precedents_text", ""))
            s |= {"id": r["id"], "scorer": "rubric-sim"}
            out.append(s)
    else:
        print("Score 1-5 each. Blind: do not look at which system wrote this.\n")
        for i, r in enumerate(sample, 1):
            print(f"\n[{i}/{len(sample)}] MESSAGE: {r['message']}\nREPLY: {r['reply']}\n")
            s = {d: int(input(f"  {d} 1-5 > ")) for d in
                 ("groundedness", "helpfulness", "tone", "safety")}
            s |= {"id": r["id"], "scorer": "human"}
            out.append(s)

    Path(args.out).write_text("\n".join(json.dumps(s) for s in out) + "\n")
    print(f"wrote {len(out)} human scores -> {args.out}")


if __name__ == "__main__":
    main()
