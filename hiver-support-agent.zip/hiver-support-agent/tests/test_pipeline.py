"""Fast invariant tests. These guard the properties the report claims."""
from __future__ import annotations
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src import config, taxonomy
from src.agent.route import decide
from src.agent.classify import classify
from src.llm import get_provider, parse_json
from src.eval.grounding_check import check
from src.eval.agreement import quadratic_weighted_kappa
from src.data.load import normalise


def test_sensitive_intents_never_auto():
    for intent in taxonomy.INTENT_NAMES:
        if taxonomy.INTENTS[intent]["sensitive"]:
            d = decide("please help", intent, 0.99, 0.99, False)
            assert d.action == "escalate", intent


def test_every_decision_has_a_reason():
    d = decide("app crashes", "playback_issue", 0.9, 0.5, False)
    assert d.action == "auto" and d.reason and d.rule


def test_legal_cue_outranks_everything():
    d = decide("im getting a lawyer", "playback_issue", 0.99, 0.99, False)
    assert d.action == "escalate" and d.rule == "legal_fraud_media"


def test_low_confidence_escalates():
    d = decide("hmm", "playback_issue", 0.1, 0.9, False)
    assert d.action == "escalate" and d.rule == "low_confidence"


def test_classifier_never_emits_out_of_taxonomy_label():
    class Rogue:
        def complete(self, *a, **k): return '{"intent":"refund_please","confidence":0.9}'
    c = classify(Rogue(), "hi")
    assert c.intent in taxonomy.INTENT_NAMES and c.fallback_used


def test_classifier_survives_garbage():
    class Broken:
        def complete(self, *a, **k): return "I'm sorry, I can't do that."
    assert classify(Broken(), "hi").intent in taxonomy.INTENT_NAMES


def test_parse_json_handles_fences_and_prose():
    assert parse_json('```json\n{"a":1}\n```')["a"] == 1
    assert parse_json('Here you go: {"a": 2} hope that helps')["a"] == 2


def test_grounding_flags_completed_action_as_critical():
    r = check("We've refunded you already.", "sorry, DM us")
    assert not r.supported and r.severity == "critical"


def test_grounding_passes_supported_reply():
    assert check("Try a reinstall.", "Try a reinstall and restart.").supported


def test_normalise_strips_handles_and_urls():
    out = normalise("@SpotifyCares see https://x.com/a   now")
    assert "@" not in out and "http" not in out and "  " not in out


def test_qwk_identical_is_one():
    assert quadratic_weighted_kappa([1, 3, 5, 2], [1, 3, 5, 2]) == 1.0


def test_stub_is_deterministic():
    p, q = get_provider("stub"), get_provider("stub")
    m = "CUSTOMER MESSAGE: i want a refund\n---"
    assert p.complete("TASK: CLASSIFY", m) == q.complete("TASK: CLASSIFY", m)


if __name__ == "__main__":
    fns = [v for k, v in dict(globals()).items() if k.startswith("test_")]
    bad = 0
    for f in fns:
        try:
            f(); print(f"  PASS {f.__name__}")
        except AssertionError as e:
            bad += 1; print(f"  FAIL {f.__name__} {e}")
    print(f"\n{len(fns)-bad}/{len(fns)} passed")
    sys.exit(1 if bad else 0)
