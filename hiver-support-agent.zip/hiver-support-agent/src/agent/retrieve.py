"""Retrieve historical resolutions for grounding.

TF-IDF + cosine over the KB split. Deliberately not embeddings: see DECISIONS.md #6.
"""
from __future__ import annotations
import sys
from dataclasses import dataclass
from pathlib import Path
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from src import config
from src.data.load import Thread


@dataclass
class Precedent:
    thread_id: str
    customer_text: str
    brand_reply: str
    similarity: float


class ResolutionIndex:
    """Index of (customer opening -> brand's first reply) for ANSWERED threads only.

    Unanswered threads are excluded: an empty reply is not a resolution, and
    keeping them lets the retriever return precedents with nothing to ground on.
    """

    def __init__(self, kb_threads: list[Thread]):
        self.threads = [t for t in kb_threads if t.first_brand_reply.strip()]
        if not self.threads:
            raise ValueError("no answered threads in KB split")
        corpus = [t.opening_text for t in self.threads]
        self.vec = TfidfVectorizer(
            lowercase=True, ngram_range=(1, 2), min_df=2, max_df=0.6,
            sublinear_tf=True, strip_accents="unicode",
        )
        self.matrix = self.vec.fit_transform(corpus)

    def search(self, query: str, k: int = config.RETRIEVAL_K) -> list[Precedent]:
        q = self.vec.transform([query])
        sims = cosine_similarity(q, self.matrix).ravel()
        idx = np.argsort(-sims)[:k]
        return [
            Precedent(self.threads[i].thread_id, self.threads[i].opening_text,
                      self.threads[i].first_brand_reply, float(sims[i]))
            for i in idx if sims[i] > 0
        ]

    @staticmethod
    def support(precedents: list[Precedent]) -> float:
        """Single number for 'how well does history cover this message'."""
        return precedents[0].similarity if precedents else 0.0
