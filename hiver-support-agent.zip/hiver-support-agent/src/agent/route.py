"""Auto-handle vs escalate, with a stated reason (capability 3).

Design stance: this is a RULE layer over model outputs, not a second LLM call.
Escalation is the safety valve for the whole system - it has to be inspectable,
cheap, and identical every run. A reviewer can read it in 60 seconds and a support
lead can change a threshold without touching a prompt. See DECISIONS.md #10.

Rules fire in priority order and the FIRST match wins, so the reason shown to the
human is the most serious one, not an arbitrary one.
"""
from __future__ import annotations
import re, sys
from dataclasses import dataclass
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from src import config, taxonomy

HARM_RE = re.compile(
    r"\b(lawyer|legal action|solicitor|sue|ombudsman|gdpr|data protection|"
    r"fraud|fraudulent|stolen card|unauthorised|unauthorized|identity theft|"
    r"press|journalist|bbc|watchdog|trading standards)\b", re.I)
CHURN_RE = re.compile(r"\b(cancel(ling|ing)? my|leaving|switching to|deleting my account|"
                      r"never using|done with you)\b", re.I)
REPEAT_RE = re.compile(r"\b(third time|3rd time|fourth time|again and again|still not|"
                       r"been \d+ (days|weeks)|no (one|reply)|nobody has)\b", re.I)
VULNERABLE_RE = re.compile(r"\b(disabled|disability|bereave|my (late|deceased)|"
                           r"in hospital|carer)\b", re.I)


@dataclass
class Decision:
    action: str            # "auto" | "escalate"
    reason: str            # human-readable, always populated
    rule: str              # machine id of the firing rule
    priority: str          # "normal" | "high"


def decide(message: str, intent: str, confidence: float, retrieval_support: float,
           draft_used_fallback: bool) -> Decision:
    # --- 1. Legal / fraud / media: never auto-reply. ------------------------
    if HARM_RE.search(message):
        return Decision("escalate",
                        "Message raises legal, fraud or media exposure; a human must own the response.",
                        "legal_fraud_media", "high")

    # --- 2. Vulnerability signals. -----------------------------------------
    if VULNERABLE_RE.search(message):
        return Decision("escalate",
                        "Possible vulnerable-customer context; requires human judgement on tone and remedy.",
                        "vulnerability", "high")

    # --- 3. Intents that can move money or unlock an account. --------------
    if taxonomy.INTENTS.get(intent, {}).get("sensitive"):
        return Decision("escalate",
                        f"Intent '{intent}' can affect money or account access, which the agent "
                        f"cannot verify or perform.",
                        "sensitive_intent", "high")

    # --- 4. The model isn't sure what this even is. ------------------------
    if confidence < config.MIN_CLASSIFIER_CONFIDENCE:
        return Decision("escalate",
                        f"Intent confidence {confidence:.2f} is below the {config.MIN_CLASSIFIER_CONFIDENCE} "
                        f"threshold; routing on a guess risks a wrong-topic reply.",
                        "low_confidence", "normal")

    # --- 5. Nothing in history to ground a reply on. -----------------------
    if retrieval_support < config.MIN_RETRIEVAL_SIM:
        return Decision("escalate",
                        f"Best precedent similarity {retrieval_support:.2f} is below "
                        f"{config.MIN_RETRIEVAL_SIM}; no historical resolution to ground a reply in.",
                        "no_precedent", "normal")

    # --- 6. The drafter fell back to a generic holding reply. --------------
    if draft_used_fallback:
        return Decision("escalate",
                        "Drafting failed and produced only a generic holding reply; a human can "
                        "give a real answer.",
                        "draft_fallback", "normal")

    # --- 7. Repeat contact: the automated path has already failed once. ----
    if REPEAT_RE.search(message):
        return Decision("escalate",
                        "Customer indicates a repeat contact or unanswered issue; sending another "
                        "automated reply would compound the failure.",
                        "repeat_contact", "high")

    # --- 8. Explicit churn threat is a retention conversation. -------------
    if CHURN_RE.search(message):
        return Decision("escalate",
                        "Customer signals intent to cancel or leave; retention decisions sit with a human.",
                        "churn_risk", "high")

    if intent not in config.AUTO_HANDLE_INTENTS:
        return Decision("escalate",
                        f"Intent '{intent}' is not on the auto-handle allow-list.",
                        "not_allow_listed", "normal")

    return Decision("auto",
                    f"Intent '{intent}' is allow-listed, confidence {confidence:.2f} and precedent "
                    f"similarity {retrieval_support:.2f} both clear thresholds, and no risk cue fired.",
                    "auto_ok", "normal")
