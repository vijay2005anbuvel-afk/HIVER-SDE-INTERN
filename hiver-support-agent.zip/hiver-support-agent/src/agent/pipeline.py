"""End-to-end agent: classify -> retrieve -> draft -> route."""
from __future__ import annotations
import sys, time
from dataclasses import dataclass, asdict, field
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from src import config
from src.agent.classify import classify, Classification
from src.agent.retrieve import ResolutionIndex, Precedent
from src.agent.draft import draft_reply, Draft
from src.agent.route import decide, Decision


@dataclass
class AgentOutput:
    message: str
    intent: str
    confidence: float
    intent_rationale: str
    reply: str
    grounded: bool
    retrieval_support: float
    precedent_ids: list[str] = field(default_factory=list)
    action: str = "escalate"
    escalation_reason: str = ""
    rule: str = ""
    priority: str = "normal"
    latency_ms: int = 0

    def to_row(self) -> dict:
        return asdict(self)


class SupportAgent:
    def __init__(self, index: ResolutionIndex, provider, few_shots=None):
        self.index, self.provider, self.few_shots = index, provider, few_shots or []

    def handle(self, message: str) -> AgentOutput:
        t0 = time.perf_counter()
        cls: Classification = classify(self.provider, message, self.few_shots)
        precs: list[Precedent] = self.index.search(message)
        support = ResolutionIndex.support(precs)
        dr: Draft = draft_reply(self.provider, message, cls.intent, precs)
        dec: Decision = decide(message, cls.intent, cls.confidence, support, dr.fallback_used)
        return AgentOutput(
            message=message, intent=cls.intent, confidence=cls.confidence,
            intent_rationale=cls.rationale, reply=dr.reply,
            grounded=dr.used_precedent and not dr.fallback_used,
            retrieval_support=round(support, 4),
            precedent_ids=[p.thread_id for p in precs],
            action=dec.action, escalation_reason=dec.reason, rule=dec.rule,
            priority=dec.priority, latency_ms=int((time.perf_counter() - t0) * 1000),
        )
