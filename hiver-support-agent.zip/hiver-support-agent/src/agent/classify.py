"""Intent classification (capability 1)."""
from __future__ import annotations
import sys
from dataclasses import dataclass
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from src import taxonomy
from src.llm import parse_json, LLMError

SYSTEM = f"""TASK: CLASSIFY
You label inbound customer-support messages sent to a music-streaming brand on Twitter.

Choose EXACTLY ONE intent from this closed set:
{taxonomy.prompt_block()}

Rules:
- The text is noisy: typos, ALL CAPS, emoji, truncation, missing punctuation. Read past it.
- Classify what the customer WANTS, not the words they used. "premium" alone is not billing.
- If the message contains no actionable support request, use other_out_of_scope.
- If two intents genuinely apply, pick the one the customer would want solved first.
- confidence is your own probability that this label is right, 0.0-1.0. Be honest:
  a vague one-word message should score low. Do not default to 0.9.

Respond with ONLY this JSON object, no prose:
{{"intent": "<one of the labels above>", "confidence": <float>, "rationale": "<max 15 words>"}}"""


@dataclass
class Classification:
    intent: str
    confidence: float
    rationale: str
    fallback_used: bool = False


def classify(provider, message: str, few_shots: list[tuple[str, str]] | None = None) -> Classification:
    shots = ""
    if few_shots:
        shots = "\n\nLABELLED EXAMPLES:\n" + "\n".join(
            f"- {t!r} -> {lab}" for t, lab in few_shots
        )
    user = f"CUSTOMER MESSAGE:\n{message}\n---{shots}"
    try:
        data = parse_json(provider.complete(SYSTEM, user, json_mode=True))
        intent = str(data.get("intent", "")).strip()
        if intent not in taxonomy.INTENT_NAMES:
            # Never trust a free-text label. An out-of-taxonomy label is a
            # silent corruption of every downstream metric.
            return Classification("other_out_of_scope", 0.0,
                                  f"invalid label {intent!r}", fallback_used=True)
        conf = float(data.get("confidence", 0.5))
        return Classification(intent, max(0.0, min(1.0, conf)),
                              str(data.get("rationale", ""))[:120])
    except (LLMError, ValueError, TypeError) as e:
        return Classification("other_out_of_scope", 0.0, f"error: {e}"[:120],
                              fallback_used=True)
