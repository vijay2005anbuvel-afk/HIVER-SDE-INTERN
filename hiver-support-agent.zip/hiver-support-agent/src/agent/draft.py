"""Grounded reply drafting (capability 2)."""
from __future__ import annotations
import sys
from dataclasses import dataclass, field
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from src.agent.retrieve import Precedent
from src.llm import parse_json, LLMError

SYSTEM = """TASK: DRAFT
You write the brand's public reply to a customer on Twitter, in the brand's own voice.

You are given real past cases and how this brand actually resolved them. Those
precedents are the ONLY source of truth about this brand's policies and steps.

Hard rules:
- Ground the reply in the precedents. If they disagree with each other, follow the
  most similar one.
- NEVER invent a policy, refund outcome, timeline, compensation or URL that does not
  appear in the precedents.
- NEVER state that an action has already been taken on the account. You have no
  account access.
- If the precedents do not cover the message, say what you can and move the customer
  to a channel that can help. Do not guess.
- Under 280 characters. Warm, plain, no corporate padding. One concrete next step.
- Never ask for a password, full card number or any other secret in a public reply.

Respond with ONLY this JSON object:
{"reply": "<the reply text>", "grounded_in": [<precedent numbers used>], "used_precedent": <true|false>}"""


@dataclass
class Draft:
    reply: str
    grounded_in: list[int] = field(default_factory=list)
    used_precedent: bool = False
    fallback_used: bool = False


SAFE_FALLBACK = ("Sorry you're running into this! We'd like to take a closer look - "
                 "send us a DM with a few more details (never your password or card "
                 "number) and we'll help from there.")


def build_user_prompt(message: str, intent: str, precedents: list[Precedent]) -> str:
    parts = [f"CUSTOMER MESSAGE:\n{message}", f"PREDICTED INTENT: {intent}", "PRECEDENTS:"]
    if not precedents:
        parts.append("[none found]")
    for i, p in enumerate(precedents, 1):
        parts.append(f"[PRECEDENT {i} sim={p.similarity:.3f}]\n{p.customer_text}\n"
                     f"REPLY: {p.brand_reply}")
    return "\n".join(parts)


def draft_reply(provider, message: str, intent: str, precedents: list[Precedent]) -> Draft:
    user = build_user_prompt(message, intent, precedents)
    try:
        data = parse_json(provider.complete(SYSTEM, user, json_mode=True))
        reply = str(data.get("reply", "")).strip()
        if not reply:
            return Draft(SAFE_FALLBACK, [], False, fallback_used=True)
        if len(reply) > 400:
            reply = reply[:277].rsplit(" ", 1)[0] + "..."
        return Draft(reply, [int(x) for x in data.get("grounded_in", []) if str(x).isdigit()],
                     bool(data.get("used_precedent", False)))
    except (LLMError, ValueError, TypeError):
        return Draft(SAFE_FALLBACK, [], False, fallback_used=True)
