"""Judge-vs-human agreement. Required by the brief: an unvalidated judge is an opinion."""
from __future__ import annotations
import numpy as np
from scipy.stats import spearmanr


def quadratic_weighted_kappa(a, b, lo: int = 1, hi: int = 5) -> float:
    """Cohen's kappa with quadratic weights - the right statistic for an ordinal
    1-5 scale, because being 1 point off should not be penalised like 4 points off."""
    a, b = np.asarray(a, int), np.asarray(b, int)
    n = hi - lo + 1
    O = np.zeros((n, n))
    for x, y in zip(a, b):
        O[x - lo, y - lo] += 1
    W = np.array([[((i - j) ** 2) / ((n - 1) ** 2) for j in range(n)] for i in range(n)])
    ha = np.bincount(a - lo, minlength=n)
    hb = np.bincount(b - lo, minlength=n)
    E = np.outer(ha, hb) / max(1, len(a))
    E *= O.sum() / max(E.sum(), 1e-12)
    denom = (W * E).sum()
    return float(1 - (W * O).sum() / denom) if denom > 0 else 0.0


def agreement_report(judge_scores: list[dict], human_scores: list[dict],
                     dims=("groundedness", "helpfulness", "tone", "safety")) -> dict:
    out = {}
    for d in dims:
        j = [s[d] for s in judge_scores]
        h = [s[d] for s in human_scores]
        rho = spearmanr(j, h).correlation if len(set(j)) > 1 and len(set(h)) > 1 else float("nan")
        out[d] = {
            "qwk": round(quadratic_weighted_kappa(j, h), 4),
            "spearman": round(float(rho), 4) if rho == rho else None,
            "exact_agreement": round(float(np.mean(np.array(j) == np.array(h))), 4),
            "within_1": round(float(np.mean(np.abs(np.array(j) - np.array(h)) <= 1)), 4),
            "judge_mean": round(float(np.mean(j)), 3),
            "human_mean": round(float(np.mean(h)), 3),
            "judge_bias": round(float(np.mean(j) - np.mean(h)), 3),
        }
    jc = [0.3 * s["groundedness"] + 0.25 * s["helpfulness"] + 0.15 * s["tone"] + 0.3 * s["safety"]
          for s in judge_scores]
    hc = [0.3 * s["groundedness"] + 0.25 * s["helpfulness"] + 0.15 * s["tone"] + 0.3 * s["safety"]
          for s in human_scores]
    rho = spearmanr(jc, hc).correlation
    out["composite"] = {"spearman": round(float(rho), 4) if rho == rho else None,
                        "mae": round(float(np.mean(np.abs(np.array(jc) - np.array(hc)))), 4),
                        "n": len(jc)}
    return out


def interpret(qwk: float) -> str:
    for t, s in ((0.81, "almost perfect"), (0.61, "substantial"), (0.41, "moderate"),
                 (0.21, "fair"), (0.0, "slight")):
        if qwk >= t:
            return s
    return "none/negative"
