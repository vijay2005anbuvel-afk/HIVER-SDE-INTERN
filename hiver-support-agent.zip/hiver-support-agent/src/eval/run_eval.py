"""Run every system against the golden set and write artifacts/results.json."""
from __future__ import annotations
import argparse, json, sys, time
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from src import config, taxonomy
from src.data.load import load_brand_threads, split_threads
from src.agent.retrieve import ResolutionIndex
from src.agent.pipeline import SupportAgent
from src.baselines import TrivialBaseline, SimpleBaseline
from src.llm import get_provider
from src.eval import metrics as M
from src.eval.judge import judge_reply
from src.eval.agreement import agreement_report, interpret
from src.eval.grounding_check import corpus_report


def load_golden(path: Path) -> list[dict]:
    rows = [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]
    labelled = [r for r in rows if r.get("gold_intent")]
    if not labelled:
        raise SystemExit("golden set has no labels - run scripts/label_golden.py")
    return labelled


def evaluate(system, golden, index, judge_provider, do_judge=True, judge_n=80):
    preds, t0 = [], time.perf_counter()
    for g in golden:
        o = system.handle(g["text"])
        preds.append({
            "id": g["id"], "stratum": g["stratum"], "message": g["text"],
            "gold_intent": g["gold_intent"], "pred_intent": o.intent,
            "confidence": o.confidence,
            "gold_escalate": bool(g["gold_escalate"]), "pred_action": o.action,
            "rule": o.rule, "escalation_reason": o.escalation_reason,
            "reply": o.reply, "grounded": bool(o.grounded),
            "retrieval_support": o.retrieval_support,
            "reference_reply": g.get("reference_reply", ""),
        })
    wall = time.perf_counter() - t0

    weights = M.natural_weights(preds)
    res = {
        "n": len(preds),
        "intent_raw": M.intent_metrics(preds),
        "intent_reweighted": M.intent_metrics(preds, weights),
        "routing": M.routing_metrics(preds),
        "grounding": M.grounding_metrics(preds),
        "by_stratum": M.slice_report(preds, "stratum"),
        "confusion": M.confusion_matrix(preds),
        "seconds_total": round(wall, 2),
        "ms_per_message": round(wall * 1000 / max(1, len(preds)), 1),
    }
    res["ci"] = {
        "macro_f1": M.bootstrap_ci(preds, lambda rs: M.intent_metrics(rs)["macro_f1"]),
        "unsafe_auto_rate": M.bootstrap_ci(preds, lambda rs: M.routing_metrics(rs)["unsafe_auto_rate"]),
    }

    if do_judge:
        scores = []
        for p in preds[:judge_n]:
            precs = index.search(p["message"])
            js = judge_reply(judge_provider, p["message"], p["reply"], precs)
            p["precedents_text"] = " ".join(x.brand_reply for x in precs)
            p["judge"] = js.as_dict()
            scores.append(js)
        ok = [s for s in scores if not s.failed]
        res["judge"] = {
            "n_judged": len(scores), "n_failed": len(scores) - len(ok),
            **{d: round(sum(getattr(s, d) for s in ok) / max(1, len(ok)), 3)
               for d in ("groundedness", "helpfulness", "tone", "safety")},
            "composite": round(sum(s.composite for s in ok) / max(1, len(ok)), 3),
            "pct_safety_le_3": round(sum(1 for s in ok if s.safety <= 3) / max(1, len(ok)), 4),
        }
        # Deterministic, judge-free hallucination check over auto-sent replies.
        res["grounding_check"] = corpus_report([p for p in preds if "precedents_text" in p])
    return res, preds


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", default="sample", choices=["sample", "real"])
    ap.add_argument("--provider", default=config.DEFAULT_PROVIDER, choices=["stub", "anthropic"])
    ap.add_argument("--judge-provider", default=None)
    ap.add_argument("--golden", default=str(config.GOLDEN / "golden_set.jsonl"))
    ap.add_argument("--judge-n", type=int, default=80)
    ap.add_argument("--no-judge", action="store_true")
    args = ap.parse_args()

    threads = load_brand_threads(args.source)
    kb, _ = split_threads(threads)
    index = ResolutionIndex(kb)
    golden = load_golden(Path(args.golden))

    provider = get_provider(args.provider)
    judge_provider = get_provider(args.judge_provider or args.provider)

    # B1 trains on KB threads only. Labels for training come from a weakly-labelled
    # pass over the KB (the stub/LLM classifier), NOT from golden labels - using
    # golden labels to train a baseline we then evaluate on would be leakage.
    kb_texts = [t.opening_text for t in kb if t.first_brand_reply]
    from src.agent.classify import classify
    kb_labels = [classify(provider, t).intent for t in kb_texts]
    majority = Counter(kb_labels).most_common(1)[0][0]

    systems = {
        "B0_trivial": TrivialBaseline(majority),
        "B1_simple": SimpleBaseline(index, kb_texts, kb_labels),
        "agent": SupportAgent(index, provider),
    }

    out, all_preds = {}, {}
    for name, sysobj in systems.items():
        print(f"evaluating {name} ...", flush=True)
        res, preds = evaluate(sysobj, golden, index, judge_provider,
                              do_judge=not args.no_judge, judge_n=args.judge_n)
        out[name], all_preds[name] = res, preds

    config.ARTIFACTS.mkdir(exist_ok=True)
    for name, preds in all_preds.items():
        fn = "agent_predictions.jsonl" if name == "agent" else f"{name}_predictions.jsonl"
        (config.ARTIFACTS / fn).write_text(
            "\n".join(json.dumps(p, ensure_ascii=False) for p in preds) + "\n", encoding="utf-8")

    # judge validation against human scores, if present
    hs_path = config.ARTIFACTS / "human_scores.jsonl"
    if hs_path.exists() and not args.no_judge:
        human = {h["id"]: h for h in map(json.loads, hs_path.read_text().splitlines()) if h}
        pairs = [(p["judge"], human[p["id"]]) for p in all_preds["agent"]
                 if "judge" in p and p["id"] in human]
        if pairs:
            rep = agreement_report([a for a, _ in pairs], [b for _, b in pairs])
            rep["interpretation"] = {d: interpret(rep[d]["qwk"])
                                     for d in ("groundedness", "helpfulness", "tone", "safety")}
            rep["scorer"] = next(iter(human.values())).get("scorer", "unknown")
            out["judge_agreement"] = rep

    out["_meta"] = {"source": args.source, "provider": args.provider,
                    "brand": config.BRAND, "n_kb_threads": len(kb),
                    "n_golden": len(golden), "intents": taxonomy.INTENT_NAMES,
                    "thresholds": {"min_confidence": config.MIN_CLASSIFIER_CONFIDENCE,
                                   "min_retrieval_sim": config.MIN_RETRIEVAL_SIM}}

    path = config.ARTIFACTS / "results.json"
    path.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(f"\nwrote {path}")
    for n in ("B0_trivial", "B1_simple", "agent"):
        r = out[n]
        print(f"{n:<12} macroF1={r['intent_raw']['macro_f1']:.3f} "
              f"(rw {r['intent_reweighted']['macro_f1']:.3f})  "
              f"unsafe_auto={r['routing']['unsafe_auto_rate']:.3f}  "
              f"auto_rate={r['routing']['automation_rate']:.3f}  "
              f"judge={r.get('judge', {}).get('composite', float('nan'))}")


if __name__ == "__main__":
    main()
