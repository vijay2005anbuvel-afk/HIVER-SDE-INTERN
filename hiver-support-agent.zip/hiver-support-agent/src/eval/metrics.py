"""Automated metrics.

Three groups, in order of how much they matter:
  1. SAFETY  - unsafe auto-handle rate. One number. If it is high nothing else counts.
  2. ROUTING - escalation precision/recall. Precision is a cost metric (human time),
               recall is a risk metric (bad replies that went out).
  3. INTENT  - accuracy and macro-F1. Macro-F1 is the headline because accuracy is
               dominated by one class.
Everything is additionally reported re-weighted to the natural intent distribution.
"""
from __future__ import annotations
from collections import Counter, defaultdict
import numpy as np


def _prf(tp: float, fp: float, fn: float) -> tuple[float, float, float]:
    p = tp / (tp + fp) if tp + fp else 0.0
    r = tp / (tp + fn) if tp + fn else 0.0
    f = 2 * p * r / (p + r) if p + r else 0.0
    return p, r, f


def natural_weights(rows: list[dict]) -> dict[str, float]:
    """Importance weights mapping the (over-sampled) golden set back to the natural
    intent mix, estimated from the uniform stratum only."""
    nat = Counter(r["gold_intent"] for r in rows if r["stratum"] == "uniform")
    gold = Counter(r["gold_intent"] for r in rows)
    n_nat, n_gold = sum(nat.values()) or 1, sum(gold.values()) or 1
    return {i: (nat.get(i, 0) / n_nat) / (gold[i] / n_gold) if gold[i] else 0.0
            for i in gold}


def intent_metrics(rows: list[dict], weights: dict[str, float] | None = None) -> dict:
    w = [1.0 if weights is None else weights.get(r["gold_intent"], 0.0) for r in rows]
    total = sum(w) or 1.0
    correct = sum(wi for wi, r in zip(w, rows) if r["pred_intent"] == r["gold_intent"])

    labels = sorted({r["gold_intent"] for r in rows} | {r["pred_intent"] for r in rows})
    per, f1s = {}, []
    for lab in labels:
        tp = sum(wi for wi, r in zip(w, rows) if r["gold_intent"] == lab and r["pred_intent"] == lab)
        fp = sum(wi for wi, r in zip(w, rows) if r["gold_intent"] != lab and r["pred_intent"] == lab)
        fn = sum(wi for wi, r in zip(w, rows) if r["gold_intent"] == lab and r["pred_intent"] != lab)
        p, rc, f = _prf(tp, fp, fn)
        support = sum(1 for r in rows if r["gold_intent"] == lab)
        per[lab] = {"precision": round(p, 4), "recall": round(rc, 4),
                    "f1": round(f, 4), "support": support}
        if support:
            f1s.append(f)
    return {"accuracy": round(correct / total, 4),
            "macro_f1": round(float(np.mean(f1s)) if f1s else 0.0, 4),
            "per_class": per, "n": len(rows)}


def routing_metrics(rows: list[dict]) -> dict:
    """Positive class = 'should escalate'."""
    tp = sum(1 for r in rows if r["gold_escalate"] and r["pred_action"] == "escalate")
    fp = sum(1 for r in rows if not r["gold_escalate"] and r["pred_action"] == "escalate")
    fn = sum(1 for r in rows if r["gold_escalate"] and r["pred_action"] == "auto")
    tn = sum(1 for r in rows if not r["gold_escalate"] and r["pred_action"] == "auto")
    p, rc, f = _prf(tp, fp, fn)
    n = len(rows) or 1
    return {
        # THE safety number: gold said a human was needed, we replied anyway.
        "unsafe_auto_rate": round(fn / n, 4),
        "escalation_precision": round(p, 4),
        "escalation_recall": round(rc, 4),
        "escalation_f1": round(f, 4),
        "automation_rate": round((tn + fn) / n, 4),
        "wasted_escalations": fp,
        "confusion": {"tp": tp, "fp": fp, "fn": fn, "tn": tn},
    }


def grounding_metrics(rows: list[dict]) -> dict:
    auto = [r for r in rows if r["pred_action"] == "auto"]
    return {
        "grounded_rate_overall": round(sum(r["grounded"] for r in rows) / (len(rows) or 1), 4),
        "grounded_rate_auto_only": round(sum(r["grounded"] for r in auto) / (len(auto) or 1), 4),
        "median_retrieval_support": round(float(np.median([r["retrieval_support"] for r in rows])), 4),
        "no_precedent_rate": round(sum(1 for r in rows if r["retrieval_support"] < 0.12) / (len(rows) or 1), 4),
    }


def confusion_matrix(rows: list[dict]) -> dict:
    cm = defaultdict(Counter)
    for r in rows:
        cm[r["gold_intent"]][r["pred_intent"]] += 1
    return {g: dict(c) for g, c in cm.items()}


def slice_report(rows: list[dict], key: str) -> dict:
    out = {}
    for val in sorted({r[key] for r in rows}):
        sub = [r for r in rows if r[key] == val]
        out[str(val)] = {"n": len(sub),
                         "intent_acc": round(sum(1 for r in sub
                                                 if r["pred_intent"] == r["gold_intent"]) / len(sub), 4),
                         "unsafe_auto_rate": routing_metrics(sub)["unsafe_auto_rate"]}
    return out


def bootstrap_ci(rows: list[dict], fn, n_boot: int = 1000, seed: int = 3) -> tuple[float, float]:
    """95% percentile CI. A 200-example golden set has wide error bars and the
    report says so rather than quoting a bare point estimate."""
    rng = np.random.default_rng(seed)
    idx = np.arange(len(rows))
    vals = [fn([rows[i] for i in rng.choice(idx, len(rows), replace=True)]) for _ in range(n_boot)]
    return round(float(np.percentile(vals, 2.5)), 4), round(float(np.percentile(vals, 97.5)), 4)
