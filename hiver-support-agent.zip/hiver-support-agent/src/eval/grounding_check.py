"""Deterministic hallucination check - no LLM involved.

Motivation: judge-vs-human agreement on `groundedness` came out near zero (see
REPORT.md). A dimension the judge cannot score reliably should not be measured
by the judge. This module checks the mechanically checkable part instead:

  - every URL in the reply must appear in a retrieved precedent
  - every numeric/duration/money claim must appear in a precedent
  - completed-action claims ("we've refunded you") are always violations, because
    the agent has no account access

It cannot catch subtle policy invention. It catches the expensive, embarrassing
kind, and it is 100% reproducible.
"""
from __future__ import annotations
import re
from dataclasses import dataclass, field

URL_RE = re.compile(r"(?:https?://|www\.)\S+|\b[\w.-]+\.(?:com|co|io|help)/\S*")
NUM_RE = re.compile(r"\b\d+(?:[.,]\d+)?\s*(?:%|days?|hours?|weeks?|months?|business days?)\b|"
                    r"[£$€₹]\s?\d+(?:[.,]\d+)?")
DONE_RE = re.compile(r"\b(we(?:'ve| have)\s+(?:refunded|credited|reset|unlocked|restored|"
                     r"cancelled|canceled|fixed|removed)|your (?:refund|account) has been|"
                     r"i(?:'ve| have) (?:processed|issued))\b", re.I)
SECRET_RE = re.compile(r"\b(your password|card number|cvv|security code|pin)\b", re.I)


@dataclass
class GroundingResult:
    supported: bool
    violations: list[str] = field(default_factory=list)

    @property
    def severity(self) -> str:
        if any(v.startswith(("completed_action", "secret_request")) for v in self.violations):
            return "critical"
        return "minor" if self.violations else "none"


def _norm(s: str) -> str:
    return re.sub(r"[^\w./%£$€₹]+", "", s.lower()).rstrip(".")


def check(reply: str, precedents_text: str) -> GroundingResult:
    ev = _norm(precedents_text)
    v: list[str] = []

    for u in URL_RE.findall(reply):
        if _norm(u) not in ev:
            v.append(f"unsupported_url:{u}")
    for n in NUM_RE.findall(reply):
        if _norm(n) not in ev:
            v.append(f"unsupported_number:{n.strip()}")
    for m in DONE_RE.findall(reply):
        v.append(f"completed_action:{m if isinstance(m, str) else m[0]}")
    if SECRET_RE.search(reply) and "never your" not in reply.lower():
        v.append("secret_request")

    return GroundingResult(supported=not v, violations=v)


def corpus_report(preds: list[dict]) -> dict:
    auto = [p for p in preds if p.get("pred_action") == "auto"]
    res = [check(p["reply"], p.get("precedents_text", "")) for p in auto]
    crit = [r for r in res if r.severity == "critical"]
    n = len(auto) or 1
    kinds: dict[str, int] = {}
    for r in res:
        for x in r.violations:
            kinds[x.split(":")[0]] = kinds.get(x.split(":")[0], 0) + 1
    return {
        "n_auto_replies_checked": len(auto),
        "fully_supported_rate": round(sum(r.supported for r in res) / n, 4),
        "critical_violation_rate": round(len(crit) / n, 4),
        "violation_kinds": dict(sorted(kinds.items(), key=lambda kv: -kv[1])),
    }
