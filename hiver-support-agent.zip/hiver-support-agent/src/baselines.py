"""Baselines. Two, as required: one trivial, one simple-but-real.

B0 (trivial)  - always predict the majority intent; always auto-handle; always
                send one fixed canned reply. This is the number any system must
                beat to justify existing at all.
B1 (simple)   - TF-IDF + logistic regression for intent; nearest-neighbour
                copy-paste of the historical reply for drafting; escalate only on
                the sensitive-intent rule. No LLM anywhere. This is the honest
                competitor: it is cheap, fast, and much harder to beat than B0.
"""
from __future__ import annotations
import sys
from pathlib import Path
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src import config, taxonomy
from src.agent.pipeline import AgentOutput
from src.agent.retrieve import ResolutionIndex

CANNED = ("Thanks for reaching out! Sorry for the trouble - please DM us and we'll help.")


class TrivialBaseline:
    name = "B0_majority_canned"

    def __init__(self, majority_intent: str):
        self.majority = majority_intent

    def handle(self, message: str) -> AgentOutput:
        return AgentOutput(message=message, intent=self.majority, confidence=1.0,
                           intent_rationale="constant", reply=CANNED, grounded=False,
                           retrieval_support=0.0, action="auto",
                           escalation_reason="", rule="constant_auto")


class SimpleBaseline:
    name = "B1_tfidf_lr_nn"

    def __init__(self, index: ResolutionIndex, train_texts, train_labels):
        self.index = index
        self.clf = make_pipeline(
            TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True),
            LogisticRegression(max_iter=2000, class_weight="balanced"),
        ).fit(train_texts, train_labels)

    def handle(self, message: str) -> AgentOutput:
        probs = self.clf.predict_proba([message])[0]
        i = probs.argmax()
        intent, conf = self.clf.classes_[i], float(probs[i])
        precs = self.index.search(message, k=1)
        support = ResolutionIndex.support(precs)
        reply = precs[0].brand_reply.replace("<user> ", "") if precs else CANNED
        sensitive = taxonomy.INTENTS.get(intent, {}).get("sensitive", False)
        return AgentOutput(
            message=message, intent=intent, confidence=conf, intent_rationale="tfidf+lr",
            reply=reply, grounded=bool(precs), retrieval_support=round(support, 4),
            precedent_ids=[p.thread_id for p in precs],
            action="escalate" if sensitive else "auto",
            escalation_reason="sensitive intent" if sensitive else "",
            rule="sensitive_only",
        )
