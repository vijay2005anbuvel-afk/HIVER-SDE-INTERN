"""Generate a stand-in corpus with the EXACT schema of Kaggle twcs.csv.

Why this exists: the Kaggle download is gated and ~700MB, so a reviewer cloning
the repo cannot reproduce anything in 15 minutes. This module writes a small
noisy corpus with identical columns, so every downstream module is written
against the real schema and `--source real` swaps it in with no code change.

Everything this file produces is SYNTHETIC. See REPORT.md, section
"What is misleading about my headline number?".
"""
from __future__ import annotations
import csv, random, sys
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from src import config

# (intent, customer phrasings, brand resolution replies)
TEMPLATES = {
    "billing_and_subscription": (
        [
            "i got charged {amt} twice this month for premium, whats going on",
            "why is there a {amt} charge on my card i cancelled in {mon}",
            "hi, i want a refund please. charged after my free trial ended and i never used it",
            "I've been billed {amt} but my account still says free?? fix this",
            "cancelled premium last {mon} and you STILL took money out. absolute joke",
            "how do i downgrade from premium to free without losing my playlists",
            "my student discount didnt apply, got charged full price {amt}",
            "payment failed 3 times now, card works everywhere else",
            "im being double billed, one on paypal one on card. sort it out",
            "can i get a refund for the months i didnt use? havent opened the app since {mon}",
        ],
        [
            "Sorry about that! We don't have billing tools on Twitter, but our team can check the charge - "
            "pop us a DM with the email on the account (never your card number) and we'll take a look. /JD",
            "That doesn't sound right. Refund requests are handled by our Support team - reach out via "
            "https://spotify.com/contact and they'll review the charge on your account. /RS",
            "You can change or cancel your plan any time under Account > Your plan. Downgrading keeps all "
            "your playlists and saves. Here's the walkthrough: https://spotify.com/plan /TM",
        ],
    ),
    "account_access": (
        [
            "cant log into my account, says password incorrect but its right",
            "i think my account got hacked, theres playlists i didnt make and its playing in {city}",
            "someone else is using my account, music keeps stopping randomly and its not me",
            "reset password email never arrives. checked spam. been 2 days",
            "i signed up with facebook and now i cant get in since i deleted fb",
            "my email changed and i cant access the old one to verify, help",
            "locked out of my account after changing my email address",
            "hey my account was compromised, random device in {city} is logged in",
            "how do i log out of all devices? someone has my password",
            "two factor code never comes through to my number",
        ],
        [
            "That's not good - let's secure it. Change your password right away and then use 'Sign out "
            "everywhere' at the bottom of your account page: https://spotify.com/account /JD",
            "If the reset email isn't arriving, it may be going to an older address on the account. "
            "Send us a DM with the username and we'll check which email is on file. /RS",
            "You can recover a Facebook-linked account with the email you used there: "
            "https://spotify.com/login-help - if that address is gone, DM us and we'll help. /TM",
        ],
    ),
    "playback_issue": (
        [
            "app keeps crashing every time i open it on {device}. uninstalled twice already",
            "songs keep skipping after 10 seconds, wifi is fine",
            "my downloads disappeared again!!! third time this month",
            "why does the app freeze when i lock my phone on {device}",
            "audio quality is terrible today, sounds like a 90s radio",
            "offline mode not working, says i need to go online but i have premium",
            "spotify wont play anything, just spins forever. {device}",
            "keeps pausing every few minutes even though nothing else is open",
            "the app is so slow since the last update on {device}, unusable",
            "shuffle plays the same 20 songs from a 900 song playlist",
        ],
        [
            "Let's get that fixed. Try a clean reinstall - log out, delete the app, restart the device, "
            "then reinstall. That clears most crash loops. Full steps: https://spotify.com/reinstall /JD",
            "Sorry about that! Downloads drop off if the app hasn't been online in 30 days. Go online once "
            "and they'll restore. If they don't, DM us your device and app version. /RS",
            "Try toggling off battery optimisation for the app - it's the usual cause of background "
            "pausing on Android. Steps here: https://spotify.com/battery /TM",
        ],
    ),
    "content_missing": (
        [
            "why is {artist} not on spotify anymore, the whole album is gone",
            "half of {artist}s songs are greyed out for me",
            "the new {artist} single isnt showing up in my country",
            "podcast episodes from last week vanished from my library",
            "album artwork is wrong for {artist}, shows a completely different band",
            "why cant i play {artist} here but my friend in the US can",
            "a song i saved 3 years ago just disappeared from my liked songs",
            "{artist} tracks show up in search but wont play, greyed out",
            "the deluxe version of the album isnt on here, only the standard",
            "why has this podcast been removed, i was halfway through the series",
        ],
        [
            "Greyed-out tracks usually mean the rights holder pulled them in your region - it's not "
            "something we control, but availability does change back. /JD",
            "Thanks for flagging! Artwork and metadata come from the label's delivery. We've passed this "
            "to the content team to correct. /RS",
            "Licensing differs country to country, which is why a friend elsewhere can play it. We share "
            "every one of these reports with the licensing team. /TM",
        ],
    ),
    "device_integration": (
        [
            "cant get spotify to connect to my {car} anymore since the update",
            "alexa says it cant find my spotify account",
            "spotify connect doesnt see my {speaker}, both on same wifi",
            "bluetooth keeps disconnecting mid song in the car",
            "my {speaker} wont play spotify, other apps work fine",
            "playstation app logged me out and wont log back in",
            "how do i link spotify to my {speaker}",
            "spotify on my smartwatch just shows a loading circle forever",
            "carplay shows spotify but tapping it does nothing",
            "tv app wont accept my login, keyboard doesnt respond",
        ],
        [
            "Let's try relinking - remove the account from the device, then re-add it from "
            "https://spotify.com/connect. That fixes most pairing issues after an update. /JD",
            "For Connect, both devices need to be on the same network AND the same account. Worth "
            "restarting the router once, it clears a surprising number of these. /RS",
            "Unlink and relink the account in the voice assistant's app, then say the wake word again. "
            "Steps: https://spotify.com/voice /TM",
        ],
    ),
    "family_or_duo_plan": (
        [
            "my family plan keeps asking me to verify my address even though we live together",
            "removed a member by accident, how do i add them back",
            "my son got kicked off the family plan for no reason",
            "invite link for family plan expired before they could use it",
            "how many people can i add to duo? the page is confusing",
            "im the plan manager but i cant see my members anymore",
            "family plan says address doesnt match but it definitely does",
            "my partner is on duo with me but shes been downgraded to free",
            "can i transfer the plan manager role to someone else",
            "added a member but theyre still showing as free after 2 days",
        ],
        [
            "Address verification uses the address on the plan manager's account - everyone has to enter "
            "it exactly the same way. You can recheck it here: https://spotify.com/family /JD",
            "The plan manager can re-invite from Account > Manage your plan. Invites expire after 7 days, "
            "so a fresh link should do it. /RS",
            "You can hand over plan manager, though it needs to be done from the account page rather than "
            "here. Walkthrough: https://spotify.com/family-manage /TM",
        ],
    ),
    "feature_request_or_feedback": (
        [
            "please bring back the old shuffle button, the new one is awful",
            "can you add a sleep timer to the android app already",
            "the new home screen is so cluttered, who asked for this",
            "honestly wrapped this year was the best one yet, great job",
            "why did you move the like button i hate it",
            "PLEASE let us sort playlists by date added descending",
            "the redesign is genuinely unusable for anyone with bad eyesight",
            "love the new podcast chapters feature, really well done",
            "can we get lossless audio this decade or",
            "the ai dj is actually great, didnt expect to like it",
        ],
        [
            "Appreciate the honest feedback - we pass every bit of this to the product team, and layout "
            "changes do get revisited based on it. /JD",
            "Love hearing that, thank you! We'll make sure the team sees it. /RS",
            "Not something we can promise a date on, but it's a request we hear a lot and it's logged "
            "with the team. /TM",
        ],
    ),
    "other_out_of_scope": (
        [
            "spotify wrapped better be good this year lmao",
            "@{other} look at this",
            "who else is listening to this on repeat",
            "FOLLOW MY PLAYLIST LINK IN BIO {url}",
            "playing this at full volume at 3am, sorry neighbours",
            "ok",
            "lol",
            "streaming {artist} 500 times today for the algorithm",
            "my wrapped is going to be so embarrassing",
            "hello?",
        ],
        [
            "Thanks for the mention! If you ever need a hand with anything, we're here. /JD",
            "We're here if you need us! /RS",
        ],
    ),
}

FILL = {
    "amt": ["£9.99", "$9.99", "€10.99", "£19.98", "$5.99", "₹119"],
    "mon": ["january", "march", "june", "Feb", "august", "october"],
    "city": ["Brazil", "Texas", "Manila", "Poland", "Ohio"],
    "device": ["android", "iphone 13", "iOS", "my pixel", "windows", "mac"],
    "artist": ["Frank Ocean", "Taylor Swift", "Joji", "Arctic Monkeys", "SZA", "Drake"],
    "car": ["Ford Sync", "BMW", "Toyota", "VW"],
    "speaker": ["Sonos", "Echo Dot", "Google Nest", "Samsung TV", "Xbox"],
    "other": ["jess_m", "danny", "kaylaaa"],
    "url": ["spoti.fi/2xY", "bit.ly/3kQ"],
}

PREFIX = ["", "@{brand} ", "hey @{brand} ", "@{brand} hi ", "yo @{brand} "]
SUFFIX = ["", " please help", " ???", " 😡", " thanks", " #spotify", " 🙏", " asap", ""]
FOLLOWUPS = [
    "still not working", "ok ill try that thanks", "that fixed it, cheers",
    "ive already tried that twice", "no i dont want to DM, sort it here",
    "been 3 days and no reply", "sent you a DM", "this is ridiculous, im cancelling",
]

def _noise(text: str, rng: random.Random) -> str:
    if rng.random() < 0.18:
        i = rng.randrange(max(1, len(text) - 1))
        text = text[:i] + text[i + 1:]                 # dropped char
    if rng.random() < 0.10:
        text = text.upper()
    if rng.random() < 0.12:
        text = text.replace(" ", "  ", 1)
    if rng.random() < 0.08 and len(text) > 40:
        text = text[:rng.randrange(30, len(text))] + "…"   # truncated tweet
    return text

def _fill(tpl: str, rng: random.Random) -> str:
    out = tpl
    for key, vals in FILL.items():
        token = "{" + key + "}"
        while token in out:
            out = out.replace(token, rng.choice(vals), 1)
    return out

def build(n_threads: int = 1400, seed: int = 11, brand: str = config.BRAND) -> list[dict]:
    rng = random.Random(seed)
    # deliberately skewed, long-tailed distribution like the real data
    weights = {
        "playback_issue": 0.26, "billing_and_subscription": 0.17,
        "account_access": 0.14, "other_out_of_scope": 0.13,
        "content_missing": 0.11, "device_integration": 0.09,
        "feature_request_or_feedback": 0.06, "family_or_duo_plan": 0.04,
    }
    names, probs = list(weights), list(weights.values())
    rows, tid, t0 = [], 1_000_000, datetime(2025, 10, 1)

    for _ in range(n_threads):
        intent = rng.choices(names, probs)[0]
        cust_tpls, brand_tpls = TEMPLATES[intent]
        author = f"user_{rng.randrange(1, 9000)}"
        ts = t0 + timedelta(minutes=rng.randrange(0, 60 * 24 * 90))

        text = _noise(_fill(rng.choice(cust_tpls), rng), rng)
        text = rng.choice(PREFIX).format(brand=brand) + text + rng.choice(SUFFIX)

        inbound_id, tid = tid, tid + 1
        reply_id, tid = tid, tid + 1
        has_reply = rng.random() < 0.86          # ~14% never get answered

        rows.append({
            "tweet_id": inbound_id, "author_id": author, "inbound": "True",
            "created_at": ts.strftime("%a %b %d %H:%M:%S +0000 %Y"), "text": text,
            "response_tweet_id": str(reply_id) if has_reply else "",
            "in_response_to_tweet_id": "",
            "_gold_intent": intent,              # stripped before writing CSV
        })
        if not has_reply:
            continue

        rtext = f"@{author} " + rng.choice(brand_tpls)
        rows.append({
            "tweet_id": reply_id, "author_id": brand, "inbound": "False",
            "created_at": (ts + timedelta(minutes=rng.randrange(2, 400)))
                          .strftime("%a %b %d %H:%M:%S +0000 %Y"),
            "text": rtext, "response_tweet_id": "",
            "in_response_to_tweet_id": str(inbound_id), "_gold_intent": intent,
        })

        if rng.random() < 0.38:                  # customer follow-up turn
            f_id, tid = tid, tid + 1
            rows.append({
                "tweet_id": f_id, "author_id": author, "inbound": "True",
                "created_at": (ts + timedelta(hours=rng.randrange(1, 40)))
                              .strftime("%a %b %d %H:%M:%S +0000 %Y"),
                "text": f"@{brand} " + rng.choice(FOLLOWUPS), "response_tweet_id": "",
                "in_response_to_tweet_id": str(reply_id), "_gold_intent": intent,
            })
    return rows


def main() -> None:
    rows = build()
    config.SAMPLE.mkdir(parents=True, exist_ok=True)
    cols = ["tweet_id", "author_id", "inbound", "created_at", "text",
            "response_tweet_id", "in_response_to_tweet_id"]

    out = config.SAMPLE / "sample_twcs.csv"
    with out.open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        for r in rows:
            w.writerow({c: r[c] for c in cols})

    # gold intents kept in a side-car so the CSV stays schema-identical to twcs.csv
    side = config.SAMPLE / "sample_gold_intents.csv"
    with side.open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["tweet_id", "intent"])
        for r in rows:
            if r["inbound"] == "True" and not r["in_response_to_tweet_id"]:
                w.writerow([r["tweet_id"], r["_gold_intent"]])

    print(f"wrote {len(rows)} tweets -> {out}")


if __name__ == "__main__":
    main()
