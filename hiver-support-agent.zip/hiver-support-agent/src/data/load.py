"""Load + reconstruct threads. Works identically on real twcs.csv and the sample."""
from __future__ import annotations
import re, sys
from dataclasses import dataclass, field
from pathlib import Path
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from src import config

URL_RE = re.compile(r"https?://\S+|www\.\S+")
HANDLE_RE = re.compile(r"@\w+")
WS_RE = re.compile(r"\s+")


def normalise(text: str) -> str:
    """Light normalisation only. We deliberately keep casing-insensitive content
    but preserve punctuation like '?' and '!!!' - they carry escalation signal."""
    t = URL_RE.sub(" <url> ", str(text))
    t = HANDLE_RE.sub(" <user> ", t)
    t = t.replace("&amp;", "&").replace("&gt;", ">").replace("&lt;", "<")
    return WS_RE.sub(" ", t).strip()


@dataclass
class Thread:
    thread_id: str
    customer_id: str
    opening_text: str          # normalised first inbound message
    opening_raw: str
    brand_replies: list[str] = field(default_factory=list)
    customer_followups: list[str] = field(default_factory=list)
    resolved_hint: bool = False     # crude: did the customer thank/confirm?

    @property
    def first_brand_reply(self) -> str:
        return self.brand_replies[0] if self.brand_replies else ""


POSITIVE_CLOSE = ("thank", "thanks", "cheers", "fixed it", "that worked", "sorted", "worked")


def _resolve_path(source: str) -> Path:
    if source == "real":
        p = config.RAW / "twcs.csv"
        if not p.exists():
            raise FileNotFoundError(
                f"{p} not found. Download thoughtvector/customer-support-on-twitter "
                "from Kaggle and unzip twcs.csv into data/raw/."
            )
        return p
    return config.SAMPLE / "sample_twcs.csv"


def load_brand_threads(source: str = "sample", brand: str = config.BRAND,
                       max_threads: int | None = None) -> list[Thread]:
    """Return threads that START with an inbound message mentioning/aimed at the brand.

    Real twcs.csv is ~3M rows; we stream it in chunks and keep only the rows that
    touch the brand before doing any thread work.
    """
    path = _resolve_path(source)
    usecols = ["tweet_id", "author_id", "inbound", "created_at", "text",
               "response_tweet_id", "in_response_to_tweet_id"]
    brand_lc = brand.lower()

    # Pass 1: keep rows authored by the brand or mentioning it, and note the
    # tweet_ids those rows reply to. In the real dataset the customer's opening
    # tweet often does NOT contain the brand handle - it is only reachable
    # through the brand's reply pointer, so a single mention-filter would silently
    # drop most openers. (This cost me an evening; see DECISIONS.md #4.)
    frames, wanted = [], set()
    for chunk in pd.read_csv(path, usecols=usecols, dtype=str, chunksize=400_000):
        hit = chunk["author_id"].str.lower().eq(brand_lc) | \
              chunk["text"].fillna("").str.lower().str.contains(brand_lc, regex=False)
        sub = chunk[hit]
        frames.append(sub)
        wanted.update(sub["in_response_to_tweet_id"].dropna().astype(str))
    kept = pd.concat(frames, ignore_index=True)
    wanted -= set(kept["tweet_id"].astype(str))
    wanted.discard("")

    # Pass 2: recover the parent tweets identified above.
    if wanted:
        extra = []
        for chunk in pd.read_csv(path, usecols=usecols, dtype=str, chunksize=400_000):
            extra.append(chunk[chunk["tweet_id"].astype(str).isin(wanted)])
        kept = pd.concat([kept] + extra, ignore_index=True)

    df = kept.drop_duplicates("tweet_id").fillna({"text": "", "in_response_to_tweet_id": ""})

    # Pull in brand replies whose parent is in our set but which we may have missed.
    df["inbound_b"] = df["inbound"].astype(str).str.lower().eq("true")
    by_id = {r.tweet_id: r for r in df.itertuples()}
    children: dict[str, list] = {}
    for r in df.itertuples():
        parent = r.in_response_to_tweet_id
        if isinstance(parent, str) and parent:
            children.setdefault(parent, []).append(r)

    threads: list[Thread] = []
    for r in df.itertuples():
        if not r.inbound_b:
            continue
        parent = r.in_response_to_tweet_id
        if isinstance(parent, str) and parent and parent in by_id:
            continue                                   # not a thread opener
        text = normalise(r.text)
        if len(text) < 3:
            continue

        th = Thread(thread_id=str(r.tweet_id), customer_id=str(r.author_id),
                    opening_text=text, opening_raw=str(r.text))

        # walk the reply chain breadth-first, capped at 8 hops
        frontier, hops = [str(r.tweet_id)], 0
        while frontier and hops < 8:
            nxt = []
            for node in frontier:
                for child in children.get(node, []):
                    body = normalise(child.text)
                    if child.inbound_b:
                        th.customer_followups.append(body)
                        if any(k in body.lower() for k in POSITIVE_CLOSE):
                            th.resolved_hint = True
                    else:
                        th.brand_replies.append(body)
                    nxt.append(str(child.tweet_id))
            frontier, hops = nxt, hops + 1

        threads.append(th)
        if max_threads and len(threads) >= max_threads:
            break

    threads.sort(key=lambda t: int(t.thread_id) if t.thread_id.isdigit() else 0)
    return threads


def split_threads(threads: list[Thread], seed: int = config.SPLIT_SEED):
    """Deterministic thread-level split into (kb_threads, holdout_threads)."""
    import random
    rng = random.Random(seed)
    shuffled = threads[:]
    rng.shuffle(shuffled)
    cut = int(len(shuffled) * config.KB_FRACTION)
    return shuffled[:cut], shuffled[cut:]


if __name__ == "__main__":
    src = sys.argv[1] if len(sys.argv) > 1 else "sample"
    th = load_brand_threads(src)
    kb, ho = split_threads(th)
    answered = sum(1 for t in th if t.brand_replies)
    print(f"source={src} threads={len(th)} answered={answered} "
          f"({answered/len(th):.1%}) kb={len(kb)} holdout={len(ho)}")
    print("example:", th[0].opening_text[:90])
    print("reply  :", th[0].first_brand_reply[:90])
