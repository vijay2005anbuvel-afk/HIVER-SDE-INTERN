"""Intent taxonomy.

Derived bottom-up: 600 inbound messages to the brand were read in batches of 50,
free-text tagged, then tags merged until a batch produced no new tag (saturation
at batch 9). See DECISIONS.md #2 and #3 for why the set is this small and why
`other_out_of_scope` exists.
"""

INTENTS = {
    "billing_and_subscription": {
        "definition": "Charges, refunds, failed payments, cancelling, upgrading/downgrading, "
                      "student/trial pricing, unrecognised charges.",
        "not": "Family-plan member management (-> family_or_duo_plan).",
        "sensitive": True,
    },
    "account_access": {
        "definition": "Cannot log in, forgotten password, email/username change, account "
                      "compromised or hacked, 2FA, merged/duplicate accounts.",
        "not": "Password works but audio fails (-> playback_issue).",
        "sensitive": True,
    },
    "playback_issue": {
        "definition": "App crashes, songs skipping or not playing, downloads/offline mode, "
                      "audio quality, buffering, sync between devices.",
        "not": "Track exists nowhere in catalogue (-> content_missing).",
        "sensitive": False,
    },
    "content_missing": {
        "definition": "A song, album, podcast or artist is absent, greyed out, removed, or "
                      "region-locked. Also wrong metadata or artwork.",
        "not": "Content plays but stutters (-> playback_issue).",
        "sensitive": False,
    },
    "device_integration": {
        "definition": "Connecting to car, smart speaker, console, TV, smartwatch, Connect, "
                      "Bluetooth, third-party app linking.",
        "not": "Failure happens in-app on the phone itself (-> playback_issue).",
        "sensitive": False,
    },
    "family_or_duo_plan": {
        "definition": "Adding or removing plan members, invitations, address verification, "
                      "plan-manager changes, a member being kicked off.",
        "not": "The price of the plan itself (-> billing_and_subscription).",
        "sensitive": False,
    },
    "feature_request_or_feedback": {
        "definition": "Product asks, UI complaints, praise, opinions about a change. Nothing "
                      "is broken and there is nothing to fix.",
        "not": "Something is actually broken (-> the relevant issue intent).",
        "sensitive": False,
    },
    "other_out_of_scope": {
        "definition": "Not a support request: jokes, spam, promo, fan chatter, messages aimed "
                      "at someone else, or too little text to act on.",
        "not": "Anything with an actionable problem.",
        "sensitive": False,
    },
}

INTENT_NAMES = sorted(INTENTS)

def prompt_block() -> str:
    return "\n".join(
        f"- {n}: {INTENTS[n]['definition']} NOT: {INTENTS[n]['not']}" for n in INTENT_NAMES
    )
