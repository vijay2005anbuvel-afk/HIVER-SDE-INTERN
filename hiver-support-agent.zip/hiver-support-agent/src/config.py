"""Central config. Everything tunable lives here so the report's numbers are traceable."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
RAW = DATA / "raw"            # put the real Kaggle twcs.csv here
SAMPLE = DATA / "sample"      # bundled stand-in corpus (same schema as twcs.csv)
GOLDEN = DATA / "golden"
ARTIFACTS = ROOT / "artifacts"

# --- Brand under test -------------------------------------------------------
BRAND = "SpotifyCares"

# --- Corpus split -----------------------------------------------------------
# Threads are split by thread id, never by message, so a thread never straddles
# the knowledge base and the evaluation pool.
SPLIT_SEED = 20260919
KB_FRACTION = 0.70            # historical threads used as the resolution KB
HOLDOUT_FRACTION = 0.30       # pool the golden set is sampled from

# --- Retrieval --------------------------------------------------------------
RETRIEVAL_K = 4
MIN_RETRIEVAL_SIM = 0.12      # below this we treat the KB as "no support"

# --- Routing thresholds (see src/agent/route.py) ----------------------------
MIN_CLASSIFIER_CONFIDENCE = 0.45
AUTO_HANDLE_INTENTS = {
    "playback_issue",
    "content_missing",
    "device_integration",
    "feature_request_or_feedback",
    "other_out_of_scope",
}

# --- LLM --------------------------------------------------------------------
DEFAULT_PROVIDER = "stub"     # "stub" (offline, deterministic) | "anthropic"
ANTHROPIC_MODEL = "claude-sonnet-4-6"
MAX_TOKENS = 1000
LLM_SEED = 7
