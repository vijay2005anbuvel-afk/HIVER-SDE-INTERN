"""LLM abstraction with two providers.

- "anthropic": real API calls (needs ANTHROPIC_API_KEY).
- "stub":      offline, deterministic, no network. It is NOT a language model -
               it is a lexicon-based approximation whose only job is to make the
               pipeline and the eval harness runnable and testable by a reviewer
               with no key. Stub numbers are reported separately and are NOT the
               headline claim. See REPORT.md.

The interface is one method, `complete(system, user, json_mode)`, so swapping in
an open model is a ~10-line change.
"""
from __future__ import annotations
import json, os, re, hashlib
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src import config, taxonomy


class LLMError(RuntimeError):
    pass


# --------------------------------------------------------------------------- #
# Real provider
# --------------------------------------------------------------------------- #
class AnthropicProvider:
    name = "anthropic"

    def __init__(self, model: str = config.ANTHROPIC_MODEL):
        try:
            import anthropic
        except ImportError as e:                       # pragma: no cover
            raise LLMError("pip install anthropic") from e
        if not os.environ.get("ANTHROPIC_API_KEY"):
            raise LLMError("ANTHROPIC_API_KEY not set")
        self._client = anthropic.Anthropic()
        self.model = model
        self.calls = 0

    def complete(self, system: str, user: str, json_mode: bool = False) -> str:
        self.calls += 1
        msgs = [{"role": "user", "content": user}]
        if json_mode:
            # Prefill forces the response to start as JSON, which removes almost
            # all "Sure, here's the JSON:" preamble failures.
            msgs.append({"role": "assistant", "content": "{"})
        resp = self._client.messages.create(
            model=self.model, max_tokens=config.MAX_TOKENS, temperature=0,
            system=system, messages=msgs,
        )
        text = "".join(b.text for b in resp.content if b.type == "text")
        return ("{" + text) if json_mode else text


# --------------------------------------------------------------------------- #
# Offline stub
# --------------------------------------------------------------------------- #
# Written independently of src/data/make_sample.py templates: these are the cues
# a human would write down after reading the data, not the generator's phrasings.
LEXICON = {
    "billing_and_subscription": {
        "charge": 3, "charged": 3, "refund": 3, "billed": 3, "billing": 3, "payment": 2,
        "card": 2, "money": 2, "invoice": 2, "cancel": 2, "cancelled": 2, "subscription": 2,
        "price": 2, "student": 1, "trial": 2, "paypal": 2, "downgrade": 2, "premium": 1,
    },
    "account_access": {
        "log in": 3, "login": 3, "cant log": 3, "password": 3, "hacked": 3, "compromised": 3,
        "locked out": 3, "reset": 2, "verify": 1, "two factor": 3, "2fa": 3, "sign out": 2,
        "username": 2, "someone else": 2, "my account got": 2, "facebook": 1, "email": 1,
    },
    "playback_issue": {
        "crash": 3, "crashing": 3, "freeze": 3, "skipping": 3, "wont play": 2, "buffering": 3,
        "offline": 2, "download": 2, "downloads": 2, "audio quality": 3, "pausing": 3,
        "slow": 2, "shuffle": 2, "spins": 2, "stuck": 2, "update": 1, "app": 1, "unusable": 1,
    },
    "content_missing": {
        "greyed": 3, "grayed": 3, "not on spotify": 3, "removed": 2, "disappeared": 2,
        "vanished": 2, "not available": 3, "my country": 3, "region": 2, "album": 2,
        "artwork": 3, "podcast": 1, "deluxe": 2, "single": 1, "licensing": 2,
    },
    "device_integration": {
        "alexa": 3, "connect": 2, "bluetooth": 3, "carplay": 3, "car": 2, "sonos": 3,
        "echo": 3, "nest": 3, "playstation": 3, "xbox": 3, "tv": 2, "smartwatch": 3,
        "speaker": 2, "link": 1, "pair": 2, "wifi": 1,
    },
    "family_or_duo_plan": {
        "family plan": 3, "family": 2, "duo": 3, "plan manager": 3, "member": 2,
        "members": 2, "invite": 2, "address": 2, "kicked off": 2, "add them": 1,
    },
    "feature_request_or_feedback": {
        "please add": 3, "bring back": 3, "feature": 2, "redesign": 3, "i hate": 2,
        "love the": 2, "great job": 3, "feedback": 2, "suggestion": 2, "cluttered": 2,
        "who asked": 2, "can you add": 3, "wrapped": 1, "awful": 1,
    },
    "other_out_of_scope": {
        "lol": 3, "lmao": 3, "link in bio": 3, "follow my": 3, "repeat": 1, "ok": 1,
        "hello?": 2, "on repeat": 2, "neighbours": 2,
    },
}

ESCALATION_CUES = ("refund", "hacked", "compromised", "fraud", "lawyer", "legal",
                   "ombudsman", "cancelling", "cancel my", "unacceptable", "third time",
                   "still not", "been 3 days", "ridiculous", "gdpr", "press", "bbc")


def _score_intents(text: str) -> dict[str, float]:
    low = text.lower()
    raw = {}
    for intent, cues in LEXICON.items():
        s = sum(w for cue, w in cues.items() if cue in low)
        raw[intent] = float(s)
    if not any(raw.values()):
        raw["other_out_of_scope"] = 1.0
    total = sum(raw.values()) or 1.0
    return {k: v / total for k, v in raw.items()}, max(raw.values())


class StubProvider:
    name = "stub"

    def __init__(self, seed: int = config.LLM_SEED):
        self.seed, self.calls = seed, 0

    def _jitter(self, key: str) -> float:
        h = hashlib.md5(f"{self.seed}:{key}".encode()).hexdigest()
        return int(h[:6], 16) / 0xFFFFFF

    def complete(self, system: str, user: str, json_mode: bool = False) -> str:
        self.calls += 1
        if "TASK: CLASSIFY" in system:
            return self._classify(user)
        if "TASK: DRAFT" in system:
            return self._draft(user)
        if "TASK: JUDGE" in system:
            return self._judge(user)
        return "{}"

    # -- classify ---------------------------------------------------------- #
    def _classify(self, user: str) -> str:
        msg = user.split("CUSTOMER MESSAGE:", 1)[-1].split("---", 1)[0].strip()
        scores, evidence = _score_intents(msg)
        best = max(scores, key=scores.get)
        # Confidence must reflect BOTH how dominant the winning intent is (share)
        # and how much evidence there was at all (magnitude). Share alone hits
        # 1.0 whenever exactly one weak cue fires, which makes the routing
        # threshold useless. See DECISIONS.md #9.
        share = scores[best]
        strength = min(1.0, evidence / 6.0)
        conf = round(min(0.97, 0.18 + 0.62 * share * strength
                         + 0.14 * strength + self._jitter(msg) * 0.08), 3)
        return json.dumps({
            "intent": best, "confidence": conf,
            "rationale": f"lexical cues matched {best}",
        })

    # -- draft ------------------------------------------------------------- #
    def _draft(self, user: str) -> str:
        blocks = re.findall(r"\[PRECEDENT \d+ sim=([0-9.]+)\]\n(.*?)\nREPLY: (.*?)(?=\n\[|\Z)",
                            user, flags=re.S)
        if not blocks:
            return json.dumps({
                "reply": "Sorry you're hitting this! We can help - send us a DM with a bit "
                         "more detail and we'll take a look.",
                "grounded_in": [], "used_precedent": False,
            })
        blocks.sort(key=lambda b: -float(b[0]))
        best = blocks[0][2].strip().replace("<user> ", "").replace("<url>", "spotify.com/help")
        return json.dumps({"reply": best, "grounded_in": [1], "used_precedent": True})

    # -- judge ------------------------------------------------------------- #
    def _judge(self, user: str) -> str:
        reply = user.split("CANDIDATE REPLY:", 1)[-1].split("PRECEDENTS:", 1)[0].strip()
        prec = user.split("PRECEDENTS:", 1)[-1]
        rl = reply.lower()
        r_tok = {w for w in re.findall(r"[a-z']+", rl) if len(w) > 3}
        p_tok = {w for w in re.findall(r"[a-z']+", prec.lower()) if len(w) > 3}
        overlap = len(r_tok & p_tok) / max(1, len(r_tok))

        grounded = 1 + round(overlap * 4)
        helpful = 3 + (1 if any(k in rl for k in ("http", "dm", "account", "steps")) else 0) \
                    + (1 if len(reply) > 90 else 0)
        tone = 4 + (1 if any(k in rl for k in ("sorry", "thanks", "appreciate", "let's")) else 0) \
                 - (1 if rl.isupper() else 0)
        safety = 5 - (2 if any(k in rl for k in ("guarantee", "definitely will", "refunded you",
                                                 "we have refunded")) else 0)
        clamp = lambda x: max(1, min(5, int(x)))
        return json.dumps({
            "groundedness": clamp(grounded), "helpfulness": clamp(helpful),
            "tone": clamp(tone), "safety": clamp(safety),
            "rationale": f"token overlap with precedent {overlap:.2f}",
        })


def get_provider(name: str | None = None):
    name = name or config.DEFAULT_PROVIDER
    return AnthropicProvider() if name == "anthropic" else StubProvider()


def parse_json(text: str) -> dict:
    """LLMs emit JSON in markdown fences, with trailing prose, or truncated."""
    t = text.strip()
    t = re.sub(r"^```(?:json)?|```$", "", t, flags=re.M).strip()
    try:
        return json.loads(t)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", t, flags=re.S)
        if m:
            try:
                return json.loads(m.group(0))
            except json.JSONDecodeError:
                pass
    raise LLMError(f"unparseable JSON: {text[:180]}")
