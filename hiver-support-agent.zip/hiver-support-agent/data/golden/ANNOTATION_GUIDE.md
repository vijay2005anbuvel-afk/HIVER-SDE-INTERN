# Annotation guide — golden set

Two labels per example. Label them **in this order** and do not look at model output.

## 1. `gold_intent` (single label, closed set)

Use `src/taxonomy.py`. Decision procedure:

1. Ask "what does this person want to be different after we reply?" Label that.
2. If nothing would change — no request, no broken thing — label `other_out_of_scope`.
3. If two intents both apply, pick the one that blocks the other. *"Can't log in so
   I want a refund"* → `account_access`, because fixing access removes the refund ask.
4. Do not label from keywords. "premium" appears in playback complaints constantly.
5. If you cannot decide in 30 seconds, mark `ambiguous: true` and keep your best
   guess. Ambiguous items stay in the set — dropping them inflates every metric.

## 2. `gold_escalate` (boolean) — the question a support lead actually asks

> *Would I let this reply go out publicly, unsupervised, with no human reading it first?*

Label `gold_escalate = true` when **any** of these hold:

- The correct reply depends on something only account access can settle (a charge,
  a plan state, who owns the account).
- A wrong reply would cost money, lock someone out, or leak account information.
- There is legal, fraud, regulatory or press exposure.
- The customer is visibly at the end of their patience, or says they have already
  contacted you about this.
- The customer signals they are leaving.
- You genuinely do not understand what they are asking.

Label `false` only when a generic-but-correct public reply is clearly safe and useful.

**Deliberate note:** this rubric is written in terms of *consequences*, not in terms
of the rules in `src/agent/route.py`. That is on purpose. If the gold labels were
derived from the router's own rules, router accuracy would be a tautology.

## Sampling plan (what `scripts/build_golden_set.py` does)

Drawn **only from the holdout split**, never from the KB the retriever indexes.

| Stratum | Share | Why |
|---|---|---|
| Uniform random | 55% | Preserves the real, skewed intent distribution. Without this, headline accuracy is measured on a distribution that does not exist. |
| Rare-intent boost | 25% | Keyword-seeded oversample of low-frequency intents so macro-F1 has ≥15 examples per class instead of 3. |
| Hard cases | 20% | Very short (<25 chars), very long (>220 chars), ALL-CAPS, emoji-only, and threads the brand never answered. These are where the system fails, and uniform sampling barely contains them. |

Because strata 2 and 3 are over-represented, **every headline metric is also reported
re-weighted back to the natural distribution** (`metrics.py::reweight`). The two
numbers differ by several points. The re-weighted one is the honest one.
